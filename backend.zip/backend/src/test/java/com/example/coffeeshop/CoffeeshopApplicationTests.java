package com.example.coffeeshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeeshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
