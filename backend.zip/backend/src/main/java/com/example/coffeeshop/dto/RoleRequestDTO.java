package com.example.coffeeshop.dto;

public class RoleRequestDTO {
    private String role;

    // Getters and setters
    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}